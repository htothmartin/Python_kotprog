<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tilesetgrass" tilewidth="32" tileheight="32" tilecount="40" columns="10">
 <image source="../Pixel Art Grassland Tileset 32x32/tilesetgrass.png" width="320" height="128"/>
</tileset>
