<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="castle" tilewidth="400" tileheight="400" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="400" height="400" source="../images/castle/castle/castle.png"/>
 </tile>
</tileset>
