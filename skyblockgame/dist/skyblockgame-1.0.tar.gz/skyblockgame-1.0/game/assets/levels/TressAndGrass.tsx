<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TressAndGrass" tilewidth="192" tileheight="96" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="../../Pixel Art Grassland Tileset 32x32/bush.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="../../Pixel Art Grassland Tileset 32x32/grass.png"/>
 </tile>
 <tile id="2">
  <image width="192" height="96" source="../../Pixel Art Grassland Tileset 32x32/tree.png"/>
 </tile>
</tileset>
